<?php
$name = $_POST['name'];
$name = $_POST['email'];
$name = $_POST['subject'];
$name = $_POST['message'];

$email_from = '';    //input site email address

$email_subject = 'New Form Submission';

$email_body = "User Name: $name.\n".
                "User Email: $Visitor_email.\n".
                "User Subject: $subject.\n".
                "User Message: $message.\n";

$to = 'agbavoredem187@gmail.com';

$header = "From: $email_from \r\n";

$header .= "Reply-To: $visitor_email \r"

mail($to,$email_body,$email_subject)

header("Location: contact.html")
?>