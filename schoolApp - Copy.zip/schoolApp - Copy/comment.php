<?php
$conn = new mysqli('localhost', 'user', 'pass', 'db');
$name = $_POST['name'];
$name = $_POST['email'];
$name = $_POST['message'];

$con->query ("INSERT INTO comments (name, email, message) VALUES('$name', '$email', '$message')" );
?>

<div id="comment">
    <?php
    foreach($comment as $c) {
        echo "<p>$c</p>"
    }

    ?>
</div>